package com.example.fakenfcdemo

import android.app.Activity
import android.nfc.NfcAdapter
import android.nfc.Tag
import android.nfc.tech.Ndef
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.widget.*
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors
import kotlin.random.Random

class MainActivity : Activity() {
    // Replace with your Render HTTPS URL. Do not add a trailing slash.
    private val SERVER_URL = "https://YOUR-SERVICE.onrender.com"
    private val executor = Executors.newSingleThreadExecutor()
    private val handler = Handler(Looper.getMainLooper())
    private var nfcAdapter: NfcAdapter? = null
    private lateinit var code: String
    private lateinit var message: TextView
    private lateinit var codeView: TextView
    private var armed = false
    private var lastState = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        nfcAdapter = NfcAdapter.getDefaultAdapter(this)
        code = "%06d".format(Random.nextInt(0, 1_000_000))
        buildUi()
        registerCode()
        handleIntent(intent)
        pollStatus()
    }

    private fun buildUi() {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 36, 28, 28)
            setBackgroundColor(0xFF101827.toInt())
        }
        fun text(value: String, size: Float, color: Int, bold: Boolean = false): TextView =
            TextView(this).apply {
                text = value; textSize = size; setTextColor(color)
                gravity = Gravity.CENTER
                if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
                setPadding(0, 12, 0, 12)
            }
        layout.addView(text("FAKE NFC TERMINAL", 23f, 0xFFFFFFFF.toInt(), true))
        layout.addView(text("DEMO ONLY · НЕ НАСТОЯЩАЯ ОПЛАТА", 14f, 0xFFFFC66D.toInt(), true))
        layout.addView(text("КОД ПОДКЛЮЧЕНИЯ", 14f, 0xFFB9C7DD.toInt()))
        codeView = text(code, 42f, 0xFF79A1FF.toInt(), true)
        layout.addView(codeView)
        message = text("Терминал готов. Нажми кнопку и приложи NFC DEMO-метку.", 17f, 0xFFFFFFFF.toInt())
        layout.addView(message)
        val button = Button(this).apply { text = "Включить ожидание NFC DEMO" }
        button.setOnClickListener {
            armed = true
            message.text = "ОЖИДАНИЕ NFC DEMO-МЕТКИ\nТолько текст FAKEPAY-DEMO"
        }
        layout.addView(button)
        val reset = Button(this).apply { text = "Создать новый код" }
        reset.setOnClickListener {
            code = "%06d".format(Random.nextInt(0, 1_000_000))
            codeView.text = code
            lastState = ""
            registerCode()
            message.text = "Новый код создан. DEMO ONLY."
        }
        layout.addView(reset)
        setContentView(layout)
    }

    private fun request(path: String, body: JSONObject? = null): JSONObject {
        val conn = (URL(SERVER_URL + path).openConnection() as HttpURLConnection)
        conn.connectTimeout = 5000
        conn.readTimeout = 5000
        conn.requestMethod = if (body == null) "GET" else "POST"
        if (body != null) {
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json")
            conn.outputStream.use { it.write(body.toString().toByteArray()) }
        }
        val stream = if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream
        val result = stream.bufferedReader().use { it.readText() }
        conn.disconnect()
        return JSONObject(result)
    }

    private fun registerCode() {
        executor.execute {
            try { request("/api/register", JSONObject().put("code", code)) }
            catch (_: Exception) { handler.post { message.text = "Нет связи с сервером. Проверь SERVER_URL." } }
        }
    }

    private fun pollStatus() {
        handler.postDelayed(object : Runnable {
            override fun run() {
                executor.execute {
                    try {
                        val data = request("/api/status/$code")
                        val state = data.optString("state")
                        if (state != lastState) {
                            lastState = state
                            handler.post {
                                when (state) {
                                    "demo_success" -> {
                                        val amount = data.optDouble("amount", 0.0)
                                        message.text = "✓ ДЕМО УСПЕШНО\n${"%.2f".format(amount)}\n\nНЕ РЕАЛЬНАЯ ОПЛАТА — ДЕНЬГИ НЕ СПИСАНЫ"
                                    }
                                    "tag_detected" -> message.text = "NFC DEMO-МЕТКА ОБНАРУЖЕНА\nМожно отправить сумму с панели."
                                    else -> if (!armed) message.text = "Терминал готов. Включи ожидание NFC DEMO."
                                }
                            }
                        }
                    } catch (_: Exception) { }
                }
                handler.postDelayed(this, 1800)
            }
        }, 1500)
    }

    override fun onNewIntent(intent: android.content.Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(intent: android.content.Intent?) {
        if (!armed || intent == null) return
        @Suppress("DEPRECATION")
        val tag = if (android.os.Build.VERSION.SDK_INT >= 33) {
            intent.getParcelableExtra(NfcAdapter.EXTRA_TAG, Tag::class.java)
        } else {
            intent.getParcelableExtra(NfcAdapter.EXTRA_TAG) as? Tag
        } ?: return
        if (isDemoTag(tag)) {
            executor.execute {
                try { request("/api/nfc", JSONObject().put("code", code)) }
                catch (_: Exception) { handler.post { message.text = "Ошибка связи с DEMO-сервером." } }
            }
        } else {
            message.text = "Метка не распознана. Нужен NDEF-текст FAKEPAY-DEMO."
        }
    }

    private fun isDemoTag(tag: Tag): Boolean {
        return try {
            val ndef = Ndef.get(tag) ?: return false
            ndef.connect()
            val records = ndef.ndefMessage?.records ?: emptyArray()
            ndef.close()
            records.any { String(it.payload).contains("FAKEPAY-DEMO") }
        } catch (_: Exception) { false }
    }

    override fun onResume() {
        super.onResume()
        val adapter = nfcAdapter ?: return
        val options = android.nfc.NfcAdapter.ReaderCallback { tag ->
            if (armed && isDemoTag(tag)) {
                executor.execute {
                    try { request("/api/nfc", JSONObject().put("code", code)) }
                    catch (_: Exception) {}
                }
            }
        }
        // Reader mode is enabled only while this app is visible.
        adapter.enableReaderMode(this, options,
            NfcAdapter.FLAG_READER_NFC_A or NfcAdapter.FLAG_READER_NFC_B or
            NfcAdapter.FLAG_READER_NFC_F or NfcAdapter.FLAG_READER_NFC_V, null)
    }

    override fun onPause() {
        super.onPause()
        nfcAdapter?.disableReaderMode(this)
    }
}
