# FakeNFC Demo — Android + Render + web dashboard

**Simulation only.** This project reacts to NFC *NDEF demo tags* and displays a clearly labeled fictional payment animation. It does not read bank cards, payment credentials, card numbers, or make payments.

## Project layout
- `server/` — Flask API for Render
- `web/` — browser dashboard
- `android/` — Android Studio Kotlin app source

## 1) Deploy the server to Render
1. Create a GitHub repository and upload the contents of this folder.
2. In Render choose **New → Web Service**, connect the repository, and set **Root Directory** to `server`.
3. Runtime: Python. Build command: `pip install -r requirements.txt`.
4. Start command: `gunicorn app:app`.
5. Add environment variable `DEMO_ADMIN_KEY` with a long random value.
6. Deploy. Copy the Render HTTPS URL.

The server stores demo sessions in memory. They reset when the service restarts or redeploys; this is intentional for a small demo. Do not use it for real payment processing.

## 2) Host the dashboard
For quick testing, open `web/index.html` locally and enter:
- Server URL: your Render URL
- Admin key: the `DEMO_ADMIN_KEY` you configured

For public hosting, upload `web/` to a static host (for example GitHub Pages). The admin key is only suitable for a private demo; do not publish it in a public website. For a public deployment, add proper user authentication before sharing.

## 3) Build Android APK
1. Open `android/` in Android Studio.
2. Let Gradle sync.
3. In `app/src/main/java/com/example/fakenfcdemo/MainActivity.kt`, replace `SERVER_URL` with your Render HTTPS URL (no trailing slash).
4. Build → Build Bundle(s) / APK(s) → Build APK(s).
5. Install the generated APK on your Android phone.

The app creates a random 6-digit pairing code. Enter that code on the dashboard. Tap **Arm NFC demo** in the app, then touch an NDEF demo tag. The app only responds to NDEF tags with the text `FAKEPAY-DEMO`; it does not interact with contactless bank cards.

## NFC tag setup
Write the plain text `FAKEPAY-DEMO` to an ordinary writable NFC NDEF tag using a reputable NFC tag-writing app. Do not use bank cards or payment cards as test tags.

## Demo flow
1. Phone generates a 6-digit code and registers it with the server.
2. Dashboard enters the code and a fictional amount.
3. Dashboard sends a simulation command.
4. Phone shows a prominent **DEMO — NOT A REAL PAYMENT** success screen.

## API
- `GET /health`
- `POST /api/register` `{ "code": "123456" }`
- `GET /api/status/<code>`
- `POST /api/nfc` `{ "code": "123456" }`
- `POST /api/charge-demo` `{ "code": "123456", "amount": 12.50, "admin_key": "..." }`
- `POST /api/ack` `{ "code": "123456" }`

This is a learning prototype, not a secure payment terminal. Never enter or collect real payment details.
