import os, re, time, secrets, threading
from flask import Flask, request, jsonify
from flask_cors import CORS

app = Flask(__name__)
CORS(app)
ADMIN_KEY = os.environ.get("DEMO_ADMIN_KEY", "")
sessions = {}
lock = threading.Lock()
TTL = 60 * 60 * 8

def clean_expired():
    now = time.time()
    for code in list(sessions):
        if now - sessions[code]["updated"] > TTL:
            sessions.pop(code, None)

def valid_code(code):
    return isinstance(code, str) and re.fullmatch(r"\d{6}", code) is not None

@app.get("/health")
def health():
    return jsonify(ok=True, mode="DEMO ONLY")

@app.post("/api/register")
def register():
    data = request.get_json(silent=True) or {}
    code = data.get("code")
    if not valid_code(code):
        return jsonify(error="Code must contain exactly six digits"), 400
    with lock:
        clean_expired()
        sessions[code] = {
            "state": "waiting",
            "amount": None,
            "nfc_seen": False,
            "updated": time.time()
        }
    return jsonify(ok=True, state="waiting")

@app.get("/api/status/<code>")
def status(code):
    if not valid_code(code):
        return jsonify(error="Invalid code"), 400
    with lock:
        clean_expired()
        item = sessions.get(code)
        if not item:
            return jsonify(error="Code not found or expired"), 404
        item["updated"] = time.time()
        return jsonify(ok=True, **item)

@app.post("/api/nfc")
def nfc():
    data = request.get_json(silent=True) or {}
    code = data.get("code")
    if not valid_code(code):
        return jsonify(error="Invalid code"), 400
    with lock:
        item = sessions.get(code)
        if not item:
            return jsonify(error="Code not found"), 404
        item["nfc_seen"] = True
        item["state"] = "tag_detected"
        item["updated"] = time.time()
    return jsonify(ok=True, state="tag_detected")

@app.post("/api/charge-demo")
def charge_demo():
    data = request.get_json(silent=True) or {}
    code, amount, key = data.get("code"), data.get("amount"), data.get("admin_key")
    if not ADMIN_KEY or not secrets.compare_digest(str(key or ""), ADMIN_KEY):
        return jsonify(error="Dashboard key rejected"), 403
    if not valid_code(code):
        return jsonify(error="Invalid six-digit code"), 400
    try:
        amount = round(float(amount), 2)
    except (TypeError, ValueError):
        return jsonify(error="Enter a valid demo amount"), 400
    if not 0.01 <= amount <= 999999.99:
        return jsonify(error="Amount must be between 0.01 and 999999.99"), 400
    with lock:
        item = sessions.get(code)
        if not item:
            return jsonify(error="Code not found or expired"), 404
        item["amount"] = amount
        item["state"] = "demo_success"
        item["updated"] = time.time()
    return jsonify(ok=True, state="demo_success", amount=amount,
                   notice="SIMULATION ONLY — NO MONEY MOVED")

@app.post("/api/ack")
def ack():
    data = request.get_json(silent=True) or {}
    code = data.get("code")
    if not valid_code(code):
        return jsonify(error="Invalid code"), 400
    with lock:
        item = sessions.get(code)
        if not item:
            return jsonify(error="Code not found"), 404
        item["state"] = "waiting"
        item["amount"] = None
        item["updated"] = time.time()
    return jsonify(ok=True)
